# Contributing

If you would like to conribute please contact us here: https://discord.gg/q9gMKU6 or here: https://t.me/ourworldthegamechat. Thank you! :)

We would love to hear from you and welcome all the support we can get, thank you! :)
