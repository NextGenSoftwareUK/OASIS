
    // ================ Imports ================

use anchor_lang::prelude::*;


declare_id!("Fg6PaFpoGXkYsidMpWTK6W2BeZ7FEfcYkg476zPFsLnS");

#[program]
pub mod rwa_oracle {
    use super::*;

    // ================ Instructions ================
    /// Initialize a funding rate account for a symbol using PDA
    /// * `symbol` - Stock ticker symbol (e.g., AAPL)
    pub fn initialize_funding_rate(
        ctx: Context<InitializeFundingRate>,
        symbol: String
    ) -> Result<()> {
        // ================ Validations ================
        let funding_rate = &mut ctx.accounts.funding_rate;
        funding_rate.symbol = symbol;
        funding_rate.authority = ctx.accounts.authority.key();
        funding_rate.bump = ctx.bumps.funding_rate;
        funding_rate.rate = 0;
        funding_rate.hourly_rate = 0;
        funding_rate.mark_price = 0;
        funding_rate.spot_price = 0;
        funding_rate.premium = 0;
        funding_rate.last_updated = Clock::get()?.unix_timestamp;
        funding_rate.valid_until = Clock::get()?.unix_timestamp;

        // ================ Instruction Logic ================
        msg!("Initialized funding rate account for symbol: {}", funding_rate.symbol);
        Ok(())
    }

    /// Update funding rate for a symbol
    /// * `rate` - Annualized rate in basis points (10000 = 100%)
    /// * `hourly_rate` - Hourly rate in basis points
    /// * `mark_price` - Mark price in smallest unit (multiply by 10^8)
    /// * `spot_price` - Spot price in smallest unit (multiply by 10^8)
    /// * `premium` - Premium in smallest unit (can be negative)
    /// * `valid_until` - Unix timestamp when rate expires
    pub fn update_funding_rate(
        ctx: Context<UpdateFundingRate>,
        rate: i64,
        hourly_rate: i64,
        mark_price: u64,
        spot_price: u64,
        premium: i64,
        valid_until: i64
    ) -> Result<()> {
        // ================ Validations ================
        require!(
            ctx.accounts.authority.key() == funding_rate.authority,
            ErrorCode::Unauthorized
        );

        // ================ Instruction Logic ================
        let funding_rate = &mut ctx.accounts.funding_rate;
        funding_rate.rate = rate;
        funding_rate.hourly_rate = hourly_rate;
        funding_rate.mark_price = mark_price;
        funding_rate.spot_price = spot_price;
        funding_rate.premium = premium;
        funding_rate.last_updated = Clock::get()?.unix_timestamp;
        funding_rate.valid_until = valid_until;
        msg!("Updated funding rate for {}: rate={}, hourly_rate={}, mark={}, spot={}",
            funding_rate.symbol, rate, hourly_rate, mark_price, spot_price);
        Ok(())
    }

}

// ================ Account Structs ================
/// Accounts required for initializing a funding rate PDA
#[derive(Accounts)]
#[instruction(instruction(symbol: String))]
pub struct InitializeFundingRate<'info> {
    /// Funding rate PDA account
    #[account(init)]
    #[account(payer = authority)]
    #[account(space = 8 + FundingRate::MAX_SIZE)]
    #[account(seeds = [b"funding_rate", symbol.as_bytes()])]
    #[account(bump)]
    pub funding_rate: Account<'info, FundingRate>,
    /// Authority that signs and pays for initialization
    #[account(mut)]
    pub authority: Signer<'info>,
    /// System program
    pub system_program: Program<'info, System>,
}

/// Accounts required for updating a funding rate
#[derive(Accounts)]
pub struct UpdateFundingRate<'info> {
    /// Funding rate PDA account to update
    #[account(mut)]
    #[account(seeds = [b"funding_rate", funding_rate.symbol.as_bytes()])]
    #[account(bump = funding_rate.bump)]
    pub funding_rate: Account<'info, FundingRate>,
    /// Authority that signs the update
    pub authority: Signer<'info>,
}

// ================ Data Structures ================
/// Funding rate data stored on-chain
#[account]
#[derive(Default)]
pub struct FundingRate {
    /// Stock ticker symbol (max 10 chars)
    pub symbol: String,
    /// Authority that can update this rate
    pub authority: Pubkey,
    /// Annualized rate in basis points
    pub rate: i64,
    /// Hourly rate in basis points
    pub hourly_rate: i64,
    /// Mark price in smallest unit
    pub mark_price: u64,
    /// Spot price in smallest unit
    pub spot_price: u64,
    /// Premium in smallest unit (can be negative)
    pub premium: i64,
    /// Unix timestamp of last update
    pub last_updated: i64,
    /// Unix timestamp when rate expires
    pub valid_until: i64,
    /// PDA bump seed
    pub bump: u8,
}

impl FundingRate {
    /// Maximum size of FundingRate account
    pub fn MAX_SIZE(
        &mut self
    ) -> usize {
        4 + 10 + 32 + 8 + 8 + 8 + 8 + 8 + 8 + 8 + 1
    }

}


// ================ Custom Errors ================
#[error_code]
pub enum ErrorCode {
    #[msg("Unauthorized - caller is not the authority")]
    Unauthorized = 6000,
}











// ================ Program Derived Address (PDA) Seeds ================
/// Seed for funding rate PDA
pub const FUNDING_RATE_SEED: &[u8] = b"funding_rate";

/// Derive PDA for a funding rate account
pub fn derive_funding_rate_pda(
    symbol: String
) -> (Pubkey, u8) {
    Pubkey::find_program_address(
        &[FUNDING_RATE_SEED, symbol.as_bytes()],
        &crate::ID
    )
}



